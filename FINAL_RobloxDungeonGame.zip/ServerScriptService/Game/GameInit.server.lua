local Players=game:GetService("Players")
local DataService=require(script.Parent.DataService)
local Cross=require(script.Parent.CrossServerRaidService)

Players.PlayerAdded:Connect(function(p)
 DataService:Load(p)
 task.delay(2,function() Cross:TryRejoin(p) end)
end)

Players.PlayerRemoving:Connect(function(p)
 DataService:Save(p)
end)
