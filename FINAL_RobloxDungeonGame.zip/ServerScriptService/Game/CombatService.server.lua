local T=require(script.Parent.TelemetryService)
local C={}
function C:ApplyDamage(a,t,ctx)
 local dmg=math.floor(ctx.Base)
 t.HP.Value-=dmg
 T:Log("DMG",{A=a.Name,T=t.Name,D=dmg})
end
return C
