local T=require(game.ReplicatedStorage.GameData.Talents)
return {Apply=function(_,p,h,c) end}
