local DSS=game:GetService("DataStoreService")
local Store=DSS:GetDataStore("PLAYER_DATA_V2")
local D={}

function D:Load(p)
 local data=Store:GetAsync(p.UserId) or {Level=1,XP=0,Gold=0,Talents={},Cosmetics={}}
 for k,v in pairs(data) do p:SetAttribute(k,v) end
end

function D:Save(p)
 Store:SetAsync(p.UserId,{
  Level=p:GetAttribute("Level"),
  XP=p:GetAttribute("XP"),
  Gold=p:GetAttribute("Gold"),
  Talents=p:GetAttribute("Talents"),
  Cosmetics=p:GetAttribute("Cosmetics")
 })
end
return D
