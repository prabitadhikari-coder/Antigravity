local C=require(script.Parent.CombatService)
local S=require(game.ReplicatedStorage.GameData.Skills)
local K={};local CD={}
function K:Cast(p,t,n)
 local s=S[p:GetAttribute("Class")][n]
 CD[p]=CD[p] or {}
 if os.clock()<(CD[p][n] or 0) then return end
 CD[p][n]=os.clock()+s.Cooldown
 C:ApplyDamage(p,t,{Base=s.Damage})
end
return K
