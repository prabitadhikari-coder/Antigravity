
local G={}
local L={}
function G:Check(p,k)
 L[p]=L[p] or {};L[p][k]=(L[p][k] or 0)+1
 if L[p][k]>20 then p:Kick() end
end
return G
