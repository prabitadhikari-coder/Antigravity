
local A={}
function A:Tick(n)
 if n.HP.Value<30 then n.State='Flee' else n.State='Attack' end
end
return A
